﻿using System.ComponentModel.DataAnnotations;

namespace WebProgramlama.Models;

public enum AppointmentStatus
{
    Pending = 0,
    Approved = 1,
    Rejected = 2
}

public class Appointment
{
    public int Id { get; set; }

    public int SalonId { get; set; }
    public Salon Salon { get; set; } = null!;


    [Required]
    public int TrainerId { get; set; }
    public Trainer? Trainer { get; set; }

    [Required]
    public int ServiceId { get; set; }
    public Service? Service { get; set; }

    // Identity User Id
    [Required]
    public string UserId { get; set; } = "";

    [Required]
    public DateTime StartDateTime { get; set; }

    [Required]
    public AppointmentStatus Status { get; set; } = AppointmentStatus.Pending;

    // snapshot
    public int DurationMinutesSnapshot { get; set; }
    public decimal PriceSnapshot { get; set; }
}
