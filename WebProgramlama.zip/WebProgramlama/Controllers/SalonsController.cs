﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebProgramlama.Data;
using WebProgramlama.Models;

namespace WebProgramlama.Controllers;

[Authorize(Roles = "Admin")]
public class SalonsController : Controller
{
    private readonly ApplicationDbContext _context;
    public SalonsController(ApplicationDbContext context) => _context = context;

    public async Task<IActionResult> Index()
        => View(await _context.Salons
            .OrderByDescending(s => s.IsActive)
            .ThenBy(s => s.Name)
            .ToListAsync());

    public IActionResult Create() => View(new Salon());

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Salon salon)
    {
        if (!ModelState.IsValid) return View(salon);

        _context.Salons.Add(salon);
        await _context.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }

    public async Task<IActionResult> Edit(int id)
    {
        var salon = await _context.Salons.FindAsync(id);
        if (salon == null) return NotFound();
        return View(salon);
    }

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Salon salon)
    {
        if (id != salon.Id) return BadRequest();
        if (!ModelState.IsValid) return View(salon);

        _context.Update(salon);
        await _context.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }

    // Salon kapat / aç
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Toggle(int id)
    {
        var salon = await _context.Salons.FindAsync(id);
        if (salon == null) return NotFound();

        salon.IsActive = !salon.IsActive;
        await _context.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }

    // GET: Salons/Delete/5
    public async Task<IActionResult> Delete(int id)
    {
        var salon = await _context.Salons.FirstOrDefaultAsync(s => s.Id == id);
        if (salon == null) return NotFound();

        return View(salon);
    }

    // POST: Salons/Delete/5
    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var salon = await _context.Salons.FindAsync(id);
        if (salon == null) return NotFound();

        // Bu salondaki trainer ve service id'leri
        var trainerIds = await _context.Trainers
            .Where(t => t.SalonId == id)
            .Select(t => t.Id)
            .ToListAsync();

        var serviceIds = await _context.Services
            .Where(s => s.SalonId == id)
            .Select(s => s.Id)
            .ToListAsync();

        // Önce randevular (trainer veya service bu salona aitse)
        var appts = await _context.Appointments
            .Where(a => trainerIds.Contains(a.TrainerId) || serviceIds.Contains(a.ServiceId))
            .ToListAsync();

        if (appts.Count > 0)
            _context.Appointments.RemoveRange(appts);

        // Sonra trainers
        var trainers = await _context.Trainers.Where(t => t.SalonId == id).ToListAsync();
        if (trainers.Count > 0)
            _context.Trainers.RemoveRange(trainers);

        // Sonra services
        var services = await _context.Services.Where(s => s.SalonId == id).ToListAsync();
        if (services.Count > 0)
            _context.Services.RemoveRange(services);

        // En son salon
        _context.Salons.Remove(salon);

        await _context.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }
}
