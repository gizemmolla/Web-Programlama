using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebProgramlama.Views.Appointments
{
    public class MyModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
