﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebProgramlama.Data;
using WebProgramlama.Models;

namespace WebProgramlama.Controllers
{
    [Authorize(Roles = "Admin")]
    public class ServicesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ServicesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Services
        public async Task<IActionResult> Index()
        {
            var list = await _context.Services
                .Include(s => s.Salon)
                .OrderBy(s => s.Name)
                .ToListAsync();

            return View(list);
        }

        // GET: Services/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var service = await _context.Services
                .Include(s => s.Salon)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (service == null) return NotFound();

            return View(service);
        }

        // GET: Services/Create
        public async Task<IActionResult> Create()
        {
            ViewBag.SalonId = new SelectList(
                await _context.Salons.Where(s => s.IsActive).OrderBy(s => s.Name).ToListAsync(),
                "Id", "Name"
            );

            return View();
        }

        // POST: Services/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,DurationMinutes,Price,SalonId")] Service service)
        {
            // Salon aktif mi?
            var salonOk = await _context.Salons.AnyAsync(s => s.Id == service.SalonId && s.IsActive);
            if (!salonOk)
                ModelState.AddModelError("", "Geçerli/aktif bir salon seçmelisiniz.");

            if (!ModelState.IsValid)
            {
                ViewBag.SalonId = new SelectList(
                    await _context.Salons.Where(s => s.IsActive).OrderBy(s => s.Name).ToListAsync(),
                    "Id", "Name", service.SalonId
                );
                return View(service);
            }

            _context.Add(service);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: Services/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var service = await _context.Services.FindAsync(id);
            if (service == null) return NotFound();

            ViewBag.SalonId = new SelectList(
                await _context.Salons.OrderBy(s => s.Name).ToListAsync(),
                "Id", "Name", service.SalonId
            );

            return View(service);
        }

        // POST: Services/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,DurationMinutes,Price,SalonId")] Service service)
        {
            if (id != service.Id) return NotFound();

            // Salon var mı?
            var salonExists = await _context.Salons.AnyAsync(s => s.Id == service.SalonId);
            if (!salonExists)
                ModelState.AddModelError("", "Geçerli bir salon seçmelisiniz.");

            if (!ModelState.IsValid)
            {
                ViewBag.SalonId = new SelectList(
                    await _context.Salons.OrderBy(s => s.Name).ToListAsync(),
                    "Id", "Name", service.SalonId
                );
                return View(service);
            }

            try
            {
                _context.Update(service);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ServiceExists(service.Id)) return NotFound();
                throw;
            }

            return RedirectToAction(nameof(Index));
        }

        // GET: Services/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var service = await _context.Services
                .Include(s => s.Salon)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (service == null) return NotFound();

            return View(service);
        }

        // POST: Services/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var service = await _context.Services.FindAsync(id);
            if (service != null)
            {
                _context.Services.Remove(service);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        private bool ServiceExists(int id)
        {
            return _context.Services.Any(e => e.Id == id);
        }
    }
}
