﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;


namespace WebProgramlama.Models;

public class Service
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Hizmet adı zorunlu")]
    [StringLength(60)]
    public string Name { get; set; } = "";

    [Range(1, int.MaxValue, ErrorMessage = "Salon seçmelisiniz.")]
    public int SalonId { get; set; }

    [ValidateNever]
    public Salon Salon { get; set; } = null!;


    [Range(10, 240, ErrorMessage = "Süre 10-240 dk arası olmalı")]
    public int DurationMinutes { get; set; }

    [Column(TypeName = "decimal(10,2)")]
    public decimal Price { get; set; }
}
