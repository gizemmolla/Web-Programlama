using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebProgramlama.Views.Appointments
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
