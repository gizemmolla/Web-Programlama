﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebProgramlama.Data;
using WebProgramlama.Models;

namespace WebProgramlama.Controllers
{
    [Authorize(Roles = "Admin")]
    public class TrainersController : Controller
    {
        private static List<(string Text, int Value)> DayOptions() => new()
        {
            ("Pazartesi", 1),
            ("Salı", 2),
            ("Çarşamba", 4),
            ("Perşembe", 8),
            ("Cuma", 16),
            ("Cumartesi", 32),
            ("Pazar", 64),
        };

        private readonly ApplicationDbContext _context;

        public TrainersController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Trainers
        public async Task<IActionResult> Index()
        {
            var list = await _context.Trainers
                .Include(t => t.Salon)
                .OrderBy(t => t.FullName)
                .ToListAsync();

            return View(list);
        }

        // GET: Trainers/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var trainer = await _context.Trainers
                .Include(t => t.Salon)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (trainer == null) return NotFound();

            return View(trainer);
        }

        // GET: Trainers/Create
        public async Task<IActionResult> Create()
        {
            ViewBag.DayOptions = DayOptions();
            ViewBag.SalonId = new SelectList(
                await _context.Salons.Where(s => s.IsActive).OrderBy(s => s.Name).ToListAsync(),
                "Id", "Name"
            );

            return View();
        }

        // POST: Trainers/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(
            [Bind("Id,FullName,Specialty,Phone,WorkStart,WorkEnd,SalonId")] Trainer trainer,
            int[]? selectedDays)
        {
            selectedDays ??= Array.Empty<int>();

            trainer.WorkDays = (WorkDays)selectedDays.Sum();

            if (selectedDays.Length == 0)
                ModelState.AddModelError("", "En az bir çalışma günü seçmelisiniz.");

            var salonOk = await _context.Salons.AnyAsync(s => s.Id == trainer.SalonId && s.IsActive);
            if (!salonOk)
                ModelState.AddModelError("", "Geçerli/aktif bir salon seçmelisiniz.");

            if (!ModelState.IsValid)
            {
                ViewBag.DayOptions = DayOptions();
                ViewBag.SalonId = new SelectList(
                    await _context.Salons.Where(s => s.IsActive).OrderBy(s => s.Name).ToListAsync(),
                    "Id", "Name", trainer.SalonId
                );
                return View(trainer);
            }

            _context.Add(trainer);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: Trainers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var trainer = await _context.Trainers.FindAsync(id);
            if (trainer == null) return NotFound();

            ViewBag.DayOptions = DayOptions();
            ViewBag.SalonId = new SelectList(
                await _context.Salons.OrderBy(s => s.Name).ToListAsync(),
                "Id", "Name", trainer.SalonId
            );

            return View(trainer);
        }

        // POST: Trainers/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(
            int id,
            [Bind("Id,FullName,Specialty,Phone,WorkStart,WorkEnd,SalonId")] Trainer trainer,
            int[]? selectedDays)
        {
            if (id != trainer.Id) return NotFound();

            selectedDays ??= Array.Empty<int>();
            trainer.WorkDays = (WorkDays)selectedDays.Sum();

            if (selectedDays.Length == 0)
                ModelState.AddModelError("", "En az bir çalışma günü seçmelisiniz.");

            var salonExists = await _context.Salons.AnyAsync(s => s.Id == trainer.SalonId);
            if (!salonExists)
                ModelState.AddModelError("", "Geçerli bir salon seçmelisiniz.");

            if (!ModelState.IsValid)
            {
                ViewBag.DayOptions = DayOptions();
                ViewBag.SalonId = new SelectList(
                    await _context.Salons.OrderBy(s => s.Name).ToListAsync(),
                    "Id", "Name", trainer.SalonId
                );
                return View(trainer);
            }

            try
            {
                _context.Update(trainer);
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TrainerExists(trainer.Id)) return NotFound();
                throw;
            }

            return RedirectToAction(nameof(Index));
        }

        // GET: Trainers/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var trainer = await _context.Trainers
                .Include(t => t.Salon)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (trainer == null) return NotFound();

            return View(trainer);
        }

        // POST: Trainers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var trainer = await _context.Trainers.FindAsync(id);
            if (trainer != null)
            {
                _context.Trainers.Remove(trainer);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        private bool TrainerExists(int id)
        {
            return _context.Trainers.Any(e => e.Id == id);
        }
    }
}
