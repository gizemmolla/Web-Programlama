﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebProgramlama.Data;
using WebProgramlama.Models;

namespace WebProgramlama.Controllers;

[Authorize]
public class AppointmentsController : Controller
{
    private readonly ApplicationDbContext _context;
    private readonly UserManager<IdentityUser> _userManager;

    public AppointmentsController(ApplicationDbContext context, UserManager<IdentityUser> userManager)
    {
        _context = context;
        _userManager = userManager;
    }

    // Üye: kendi randevularım
    public async Task<IActionResult> My()
    {
        var userId = _userManager.GetUserId(User);
        var list = await _context.Appointments
            .Include(a => a.Salon)
            .Include(a => a.Trainer).ThenInclude(t => t.Salon)
            .Include(a => a.Service).ThenInclude(s => s.Salon)
            .Where(a => a.UserId == userId)
            .OrderByDescending(a => a.StartDateTime)
            .ToListAsync();

        return View(list);
    }

    // ADMIN: tüm randevular
    [Authorize(Roles = "Admin")]
    public async Task<IActionResult> Admin()
    {
        var list = await _context.Appointments
            .Include(a => a.Salon)
            .Include(a => a.Trainer).ThenInclude(t => t.Salon)
            .Include(a => a.Service).ThenInclude(s => s.Salon)
            .OrderBy(a => a.Status)
            .ThenBy(a => a.StartDateTime)
            .ToListAsync();

        return View(list);
    }

    // ADMIN: onayla
    [Authorize(Roles = "Admin")]
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Approve(int id)
    {
        var appt = await _context.Appointments.FindAsync(id);
        if (appt == null) return NotFound();

        appt.Status = AppointmentStatus.Approved;
        await _context.SaveChangesAsync();

        return RedirectToAction(nameof(Admin));
    }

    // ADMIN: reddet
    [Authorize(Roles = "Admin")]
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Reject(int id)
    {
        var appt = await _context.Appointments.FindAsync(id);
        if (appt == null) return NotFound();

        appt.Status = AppointmentStatus.Rejected;
        await _context.SaveChangesAsync();

        return RedirectToAction(nameof(Admin));
    }

    // GET: Randevu al (Salon seçmeli)
    public async Task<IActionResult> Create()
    {
        ViewBag.SalonId = new SelectList(
            await _context.Salons.Where(s => s.IsActive).OrderBy(s => s.Name).ToListAsync(),
            "Id", "Name"
        );

        ViewBag.TrainerId = new SelectList(Enumerable.Empty<SelectListItem>(), "Value", "Text");
        ViewBag.ServiceId = new SelectList(Enumerable.Empty<SelectListItem>(), "Value", "Text");

        return View();
    }

    // Salon seçince trainer listesi (AJAX)
    [HttpGet]
    public async Task<IActionResult> TrainersBySalon(int salonId)
    {
        var list = await _context.Trainers
            .Where(t => t.SalonId == salonId)
            .OrderBy(t => t.FullName)
            .Select(t => new { id = t.Id, text = t.FullName })
            .ToListAsync();

        return Json(list);
    }

    // Salon seçince service listesi (AJAX)
    [HttpGet]
    public async Task<IActionResult> ServicesBySalon(int salonId)
    {
        var list = await _context.Services
            .Where(s => s.SalonId == salonId)
            .OrderBy(s => s.Name)
            .Select(s => new { id = s.Id, text = s.Name })
            .ToListAsync();

        return Json(list);
    }

    // POST: Randevu al (Salon doğrulamalı)
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(int salonId, int trainerId, int serviceId, DateTime startDateTime)
    {
        var userId = _userManager.GetUserId(User);

        var salonOk = await _context.Salons.AnyAsync(s => s.Id == salonId && s.IsActive);
        if (!salonOk)
            ModelState.AddModelError("", "Seçtiğiniz salon aktif değil. Lütfen başka bir salon seçin.");

        var trainer = await _context.Trainers.FirstOrDefaultAsync(t => t.Id == trainerId);
        if (trainer == null) return NotFound();

        var service = await _context.Services.FirstOrDefaultAsync(s => s.Id == serviceId);
        if (service == null) return NotFound();

        // Trainer/Service bu salonun mu?
        if (trainer.SalonId != salonId)
            ModelState.AddModelError("", "Seçtiğiniz eğitmen bu salona ait değil.");

        if (service.SalonId != salonId)
            ModelState.AddModelError("", "Seçtiğiniz hizmet bu salona ait değil.");

        // Trainer çalışıyor mu?
        var selectedDay = ToWorkDayFlag(startDateTime.DayOfWeek);
        if (!trainer.WorkDays.HasFlag(selectedDay))
            ModelState.AddModelError("", "Seçtiğiniz tarihte bu eğitmen çalışmıyor.");

        // Saat aralığı
        var time = startDateTime.TimeOfDay;
        if (time < trainer.WorkStart || time >= trainer.WorkEnd)
            ModelState.AddModelError("", $"Eğitmen çalışma saatleri: {trainer.WorkStart:hh\\:mm} - {trainer.WorkEnd:hh\\:mm}");

        // Çakışma kontrolü
        var clash = await _context.Appointments.AnyAsync(a =>
            a.TrainerId == trainerId &&
            a.StartDateTime == startDateTime &&
            (a.Status == AppointmentStatus.Pending || a.Status == AppointmentStatus.Approved));

        if (clash)
            ModelState.AddModelError("", "Bu eğitmen bu saat diliminde müsait değil.");

        if (!ModelState.IsValid)
        {
            ViewBag.SalonId = new SelectList(
                await _context.Salons.Where(s => s.IsActive).OrderBy(s => s.Name).ToListAsync(),
                "Id", "Name", salonId
            );

            ViewBag.TrainerId = new SelectList(
                await _context.Trainers.Where(t => t.SalonId == salonId).OrderBy(t => t.FullName).ToListAsync(),
                "Id", "FullName", trainerId
            );

            ViewBag.ServiceId = new SelectList(
                await _context.Services.Where(s => s.SalonId == salonId).OrderBy(s => s.Name).ToListAsync(),
                "Id", "Name", serviceId
            );

            return View();
        }

        var appt = new Appointment
        {
            SalonId = salonId,               // ✅ KRİTİK: bunu ekledik
            TrainerId = trainerId,
            ServiceId = serviceId,
            UserId = userId!,
            StartDateTime = startDateTime,
            Status = AppointmentStatus.Pending,
            DurationMinutesSnapshot = service.DurationMinutes,
            PriceSnapshot = service.Price
        };

        _context.Appointments.Add(appt);
        await _context.SaveChangesAsync();

        return RedirectToAction(nameof(My));
    }

    private static WorkDays ToWorkDayFlag(DayOfWeek day) => day switch
    {
        DayOfWeek.Monday => WorkDays.Mon,
        DayOfWeek.Tuesday => WorkDays.Tue,
        DayOfWeek.Wednesday => WorkDays.Wed,
        DayOfWeek.Thursday => WorkDays.Thu,
        DayOfWeek.Friday => WorkDays.Fri,
        DayOfWeek.Saturday => WorkDays.Sat,
        DayOfWeek.Sunday => WorkDays.Sun,
        _ => WorkDays.None
    };
}
