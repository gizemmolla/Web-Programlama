﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using WebProgramlama.Models;
using WebProgramlama.Data;

namespace WebProgramlama.Data;

public static class DbSeeder
{
    public static async Task SeedAsync(IServiceProvider services)
    {
        using var scope = services.CreateScope();

        var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
        var userManager = scope.ServiceProvider.GetRequiredService<UserManager<IdentityUser>>();
        var context = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();

        // 1) Roller
        await EnsureRoleAsync(roleManager, "Admin");
        await EnsureRoleAsync(roleManager, "Member");

        // 2) Admin kullanıcı
        var adminEmail = "b231210094@sakarya.edu.tr";
        var adminPassword = "sau"; // çalışıyorsa kalsın, sorun çıkarsa Sau123!! yap

        var admin = await userManager.FindByEmailAsync(adminEmail);
        if (admin == null)
        {
            admin = new IdentityUser
            {
                UserName = adminEmail,
                Email = adminEmail,
                EmailConfirmed = true
            };

            var createResult = await userManager.CreateAsync(admin, adminPassword);
            if (!createResult.Succeeded)
                throw new Exception("Admin create failed: " +
                    string.Join(" | ", createResult.Errors.Select(e => e.Description)));
        }

        // 3) Admin rolüne ata
        if (!await userManager.IsInRoleAsync(admin, "Admin"))
        {
            var addRoleResult = await userManager.AddToRoleAsync(admin, "Admin");
            if (!addRoleResult.Succeeded)
                throw new Exception("AddToRole failed: " +
                    string.Join(" | ", addRoleResult.Errors.Select(e => e.Description)));
        }

        // 4) Salon seed (EN AZ 1 TANE)
        if (!await context.Salons.AnyAsync())
        {
            context.Salons.Add(new Salon
            {
                Name = "Merkez Salon",
                IsActive = true
            });

            await context.SaveChangesAsync();
        }
    }

    private static async Task EnsureRoleAsync(RoleManager<IdentityRole> roleManager, string roleName)
    {
        if (!await roleManager.RoleExistsAsync(roleName))
        {
            var result = await roleManager.CreateAsync(new IdentityRole(roleName));
            if (!result.Succeeded)
                throw new Exception($"Role create failed ({roleName}): " +
                    string.Join(" | ", result.Errors.Select(e => e.Description)));
        }
    }
}
