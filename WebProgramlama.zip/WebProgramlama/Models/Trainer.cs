﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;

namespace WebProgramlama.Models;

[Flags]
public enum WorkDays
{
    None = 0,
    Mon = 1,
    Tue = 2,
    Wed = 4,
    Thu = 8,
    Fri = 16,
    Sat = 32,
    Sun = 64
}

public class Trainer
{
    public int Id { get; set; }

    [Required]
    [StringLength(60)]
    public string FullName { get; set; } = "";


    [Range(1, int.MaxValue, ErrorMessage = "Salon seçmelisiniz.")]
    public int SalonId { get; set; }

    [ValidateNever]
    public Salon Salon { get; set; } = null!;

    [Required]
    [StringLength(120)]
    public string Specialty { get; set; } = "";

    // ÇALIŞMA GÜNLERİ VE SAATLERİ
    [Required]
    public WorkDays WorkDays { get; set; }

    [Required]
    public TimeSpan WorkStart { get; set; }

    [Required]
    public TimeSpan WorkEnd { get; set; }

    [Phone]
    [StringLength(20)]
    public string? Phone { get; set; }
}