﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebProgramlama.Data;
using WebProgramlama.Models;

namespace WebProgramlama.Controllers;

[Route("api/trainers")]
[ApiController]
public class TrainersApiController : ControllerBase
{
    private readonly ApplicationDbContext _context;

    public TrainersApiController(ApplicationDbContext context)
    {
        _context = context;
    }

    // ✅ LINQ örnek 1: tüm eğitmenleri listele
    // GET: /api/trainers
    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        var list = await _context.Trainers
            .OrderBy(t => t.FullName)
            .Select(t => new
            {
                t.Id,
                t.FullName,
                t.Specialty,
                WorkDays = t.WorkDays.ToString(),
                WorkStart = t.WorkStart.ToString(@"hh\:mm"),
                WorkEnd = t.WorkEnd.ToString(@"hh\:mm")
            })
            .ToListAsync();

        return Ok(list);
    }

    // ✅ LINQ filtre: belirli tarihte çalışan eğitmenleri getir
    // GET: /api/trainers/available?date=2025-12-22
    [HttpGet("available")]
    public async Task<IActionResult> Available([FromQuery] DateTime date)
    {
        var flag = ToWorkDayFlag(date.DayOfWeek);

        var list = await _context.Trainers
            .Where(t => (t.WorkDays & flag) == flag)  // ✅ LINQ filtre
            .OrderBy(t => t.FullName)
            .Select(t => new
            {
                t.Id,
                t.FullName,
                t.Specialty
            })
            .ToListAsync();

        return Ok(new
        {
            date = date.ToString("yyyy-MM-dd"),
            day = date.DayOfWeek.ToString(),
            count = list.Count,
            trainers = list
        });
    }

    private static WorkDays ToWorkDayFlag(DayOfWeek day) => day switch
    {
        DayOfWeek.Monday => WorkDays.Mon,
        DayOfWeek.Tuesday => WorkDays.Tue,
        DayOfWeek.Wednesday => WorkDays.Wed,
        DayOfWeek.Thursday => WorkDays.Thu,
        DayOfWeek.Friday => WorkDays.Fri,
        DayOfWeek.Saturday => WorkDays.Sat,
        DayOfWeek.Sunday => WorkDays.Sun,
        _ => WorkDays.None
    };
}
